from setuptools import setup

setup(name='dspt12-lambda-panda', version='0.0.1', author='me', author_email='michael-herndon@lambdastudents.com',
      keywords=['tweitter', 'pycharm', 'python', 'nlp'], packages=['TwitterApp'], python_requires='>=3.6, <4',
      install_requires='')
